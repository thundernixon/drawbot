stroke(0)
for i in range(50):
    point1 = (randint(0,1000),randint(0,1000))
    point2 = (randint(0,1000),randint(0,1000))
    line(point1,point2)