Variable([
    dict(name="x", ui="Slider"),
    dict(name="y", ui="Slider"),
    dict(name="w", ui="Slider"),
    dict(name="h", ui="Slider"),
    

    ], globals())

print(x)
pos = (98, 88)
rect(pos[0],pos[1],w*10,h*10)