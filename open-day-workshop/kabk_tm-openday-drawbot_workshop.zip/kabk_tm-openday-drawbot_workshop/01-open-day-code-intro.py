message = "type and media"
print(message)

# x, y, w, h
x = 200
y = 200
w = 200
h = 200
# rect(100,100,100,100)
rect(x,y,w,h)

oval(300,100,100,100)



